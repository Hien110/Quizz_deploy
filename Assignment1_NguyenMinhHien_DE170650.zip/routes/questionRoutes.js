const express = require('express');
const mongoose = require('mongoose');
const Question = require('../models/Question');

const questionRouter = express.Router();
questionRouter.use(express.json());
questionRouter.use(express.urlencoded({ extended: true }));

questionRouter
    .get('/', async (req, res) => {
        try {
            const questions = await Question.find();
            res.status(200).json(questions);
        } catch (err){
            res.status(500).json({ message: 'Error fetching questions' });
        }
    })

    .post('/', async (req, res) => {
        try {
            const question = new Question(req.body);
            await question.save();
            res.status(201).json();
        } catch (err) {
            res.status(400).json({message: err.message})
        }
    })

module.exports = questionRouter;